#include "Messenger.h"

Messenger::Messenger(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	//time = 0;
	//timer = new QTimer(this);
	//connect(timer, SIGNAL(timeout()), this, SLOT(timer_slot()));
	//timer->start(400);
	socket = new QTcpSocket(this);
	connect(socket, &QTcpSocket::readyRead, this, &Messenger::readyRead);
	//connect(socket, &QTcpSocket::disconnected, socket, &QTcpSocket::deleteLater);

	next_block_size = 0;
	keyEnter = new QShortcut(this);
	keyEnter->setKey(Qt::Key_Return);
	connect(keyEnter, &QShortcut::activated, this, &Messenger::send_message);
}

Messenger::~Messenger()
{}

void Messenger::set_socket(QTcpSocket * socket)
{
	this->socket = socket;
}

void Messenger::set_my_login(QString my_login)
{
	this->my_login = my_login;
	ui.lbl_my_login->setText(this->my_login);
}

void Messenger::set_my_userid(int id)
{
	my_userid = id;
	get_user_list();
}

void Messenger::set_ip_address(QString ip_address)
{
	this->ip_address = ip_address;
}

void Messenger::update_my_data()
{
	QJsonObject js_outpkg = {
		{"TYPE" , "UPDATEMYDATA" },
		{"MYNAME", my_login},
		{"USERID", my_userid},
		{"DATA", NULL},
		{"STATUS", NULL},
		{"SENDTO", js_user_selected["USERID"].toInt()}
	};
	sendToServer(js_outpkg);
}

void Messenger::readyRead()
{
	QDataStream in(socket);
	in.setVersion(QDataStream::Qt_6_5);
	if (in.status() == QDataStream::Ok)
	{
		while (true)
		{
			if (next_block_size == 0)
			{
				if (socket->bytesAvailable() < 2) break;
				in >> next_block_size;
			}
			if (socket->bytesAvailable() < next_block_size) break;
			in >> js_inpkg;
			next_block_size = 0;
			if (js_inpkg.value("TYPE").toString() == "GETUSERSLIST")
			{
				if (js_inpkg.value("STATUS").toString() == "TRUE")
				{
					QStringList temp_users_names;
					ui.list_friends->clear();
					for (auto user : js_inpkg.value("DATA").toArray())
					{
						temp_users_names.append(user.toString());
						QListWidgetItem* newItem = new QListWidgetItem;
						if (user.toString() != my_login)
						{
							newItem->setText(user.toString());
							ui.list_friends->addItem(newItem);
						}
					}
					QVector<int> users_id;
					for (auto id : js_inpkg.value("USERSID").toArray())
						users_id.push_back(id.toInt());

					QStringList::iterator it_temp_users_names = temp_users_names.begin();
					QVector<int>::iterator it_users_id = users_id.begin();
					while ((it_temp_users_names != temp_users_names.end()) && (it_users_id != users_id.end()))
					{
						m_users[*it_temp_users_names] = *it_users_id;
						/*QMessageBox msgBox;
						msgBox.setText(QString::number (*it_users_id));
						msgBox.exec();*/
						++it_temp_users_names;
						++it_users_id;
					}

				}
				else if (js_inpkg.value("STATUS").toString() == "False")
				{
					QMessageBox msgBox;
					msgBox.setText("Error");
					msgBox.exec();
				}
			}
			if (js_inpkg.value("TYPE").toString() == "UPDATEMYDATA")
			{
				if (js_user_selected.value("USERID").toInt() == js_inpkg.value("SENDTO").toInt())
				{
					QVector<int> users_id;
					for (auto id : js_inpkg.value("USERSID").toArray())
						users_id.append(id.toInt());
					QVector<int>::iterator it_users_id = users_id.begin();

					QStringList messages;
					for (auto message : js_inpkg.value("MESSAGES").toArray())
						messages.append(message.toString());
					QStringList::iterator it_messages = messages.begin();

					QVector<int> sends_to;
					for (auto send_to : js_inpkg.value("SENDSTO").toArray())
						sends_to.append(send_to.toInt());
					QVector<int>::iterator it_sends_to = sends_to.begin();

					ui.textBrowser->clear();

					while ((it_users_id != users_id.end()) && (it_messages != messages.end()) && (it_sends_to != sends_to.end()))
					{
						if ((*it_users_id == my_userid) && (*it_sends_to == js_user_selected.value("USERID").toInt()))
						{
							ui.textBrowser->append("[Your]\n" + *it_messages);
						}
						if ((js_user_selected.value("USERID").toInt() == *it_users_id) && (my_userid == *it_sends_to))
						{
							ui.textBrowser->append("[" + js_user_selected.value("LOGIN").toString() + "]" + "\n" + *it_messages);
						}

						++it_users_id;
						++it_messages;
						++it_sends_to;
					}
				}
				
			}
			break;
		}
	}
}

void Messenger::user_selected(QListWidgetItem* item)
{
	js_user_selected["LOGIN"] = item->text();
	js_user_selected["USERID"] = m_users[item->text()];
	update_my_data();
}

void Messenger::send_message()
{
	if ((ui.le_message->text() != ""))
	{
		QJsonObject js_outpkg = {
			{"TYPE", "MESSAGE"},
			{"MYNAME", my_login},
			{"USERID", my_userid},
			{"DATA", ui.le_message->text()},
			{"STATUS", NULL},
			{"SENDTO", js_user_selected["USERID"].toInt()}
		};
		ui.le_message->clear();
		sendToServer(js_outpkg);
	}
}

void Messenger::sendToServer(const QJsonObject& js_pkg)
{
	data.clear();
	QDataStream out(&data, QIODevice::ReadWrite);
	out.setVersion(QDataStream::Qt_6_5);
	out << quint64(0) << js_pkg;
	out.device()->seek(0);
	out << (quint64)(data.size() - sizeof(quint64));
	socket->write(data);
}

void Messenger::get_user_list()
{
	QJsonObject js_outpkg = {
		{"TYPE" , "GETUSERSLIST" },
		{"MYNAME", my_login},
		{"DATA", NULL},
		{"USERID", my_userid},
		{"STATUS", NULL}
	};
	socket->connectToHost(ip_address, 2000);
	sendToServer(js_outpkg);
}

void Messenger::get_signal_interface(QJsonObject js_pkg)
{
	/*if (js_pkg.value("TYPE").toString() == "USERSLIST")
	{
		for (QJsonValue user : js_pkg.value("DATA").toArray())
		{
			QListWidgetItem* newItem = new QListWidgetItem;
			newItem->setText(user.toString());
			ui.list_friends->addItem(newItem);
			delete newItem;
		}
	}*/
}