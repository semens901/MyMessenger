/********************************************************************************
** Form generated from reading UI file 'Messenger.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MESSENGER_H
#define UI_MESSENGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MessengerClass
{
public:
    QWidget *centralWidget;
    QLineEdit *le_message;
    QPushButton *btn_send;
    QTextBrowser *textBrowser;
    QListWidget *list_friends;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MessengerClass)
    {
        if (MessengerClass->objectName().isEmpty())
            MessengerClass->setObjectName("MessengerClass");
        MessengerClass->resize(535, 400);
        centralWidget = new QWidget(MessengerClass);
        centralWidget->setObjectName("centralWidget");
        le_message = new QLineEdit(centralWidget);
        le_message->setObjectName("le_message");
        le_message->setGeometry(QRect(30, 310, 401, 22));
        btn_send = new QPushButton(centralWidget);
        btn_send->setObjectName("btn_send");
        btn_send->setGeometry(QRect(440, 310, 75, 24));
        textBrowser = new QTextBrowser(centralWidget);
        textBrowser->setObjectName("textBrowser");
        textBrowser->setGeometry(QRect(210, 10, 301, 291));
        list_friends = new QListWidget(centralWidget);
        list_friends->setObjectName("list_friends");
        list_friends->setGeometry(QRect(0, 10, 201, 291));
        MessengerClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MessengerClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 535, 22));
        MessengerClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MessengerClass);
        mainToolBar->setObjectName("mainToolBar");
        MessengerClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MessengerClass);
        statusBar->setObjectName("statusBar");
        MessengerClass->setStatusBar(statusBar);

        retranslateUi(MessengerClass);
        QObject::connect(list_friends, SIGNAL(itemClicked(QListWidgetItem*)), MessengerClass, SLOT(user_selected(QListWidgetItem*)));
        QObject::connect(btn_send, SIGNAL(clicked()), MessengerClass, SLOT(send_message()));

        QMetaObject::connectSlotsByName(MessengerClass);
    } // setupUi

    void retranslateUi(QMainWindow *MessengerClass)
    {
        MessengerClass->setWindowTitle(QCoreApplication::translate("MessengerClass", "Messenger", nullptr));
        btn_send->setText(QCoreApplication::translate("MessengerClass", "Send", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MessengerClass: public Ui_MessengerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MESSENGER_H
