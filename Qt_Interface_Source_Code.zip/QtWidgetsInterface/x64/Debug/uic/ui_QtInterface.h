/********************************************************************************
** Form generated from reading UI file 'QtInterface.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTINTERFACE_H
#define UI_QTINTERFACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtInterfaceClass
{
public:
    QWidget *centralWidget;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLineEdit *le_login;
    QLabel *label_2;
    QLineEdit *le_password;
    QPushButton *btn_log_in;
    QPushButton *btn_sign_up;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtInterfaceClass)
    {
        if (QtInterfaceClass->objectName().isEmpty())
            QtInterfaceClass->setObjectName("QtInterfaceClass");
        QtInterfaceClass->resize(214, 273);
        centralWidget = new QWidget(QtInterfaceClass);
        centralWidget->setObjectName("centralWidget");
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(30, 40, 158, 128));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName("verticalLayout");
        label = new QLabel(layoutWidget);
        label->setObjectName("label");

        verticalLayout->addWidget(label);

        le_login = new QLineEdit(layoutWidget);
        le_login->setObjectName("le_login");

        verticalLayout->addWidget(le_login);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName("label_2");

        verticalLayout->addWidget(label_2);

        le_password = new QLineEdit(layoutWidget);
        le_password->setObjectName("le_password");
        le_password->setMaxLength(32767);

        verticalLayout->addWidget(le_password);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 2);

        btn_log_in = new QPushButton(layoutWidget);
        btn_log_in->setObjectName("btn_log_in");

        gridLayout->addWidget(btn_log_in, 1, 1, 1, 1);

        btn_sign_up = new QPushButton(layoutWidget);
        btn_sign_up->setObjectName("btn_sign_up");

        gridLayout->addWidget(btn_sign_up, 1, 0, 1, 1);

        QtInterfaceClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QtInterfaceClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 214, 22));
        QtInterfaceClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QtInterfaceClass);
        mainToolBar->setObjectName("mainToolBar");
        QtInterfaceClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QtInterfaceClass);
        statusBar->setObjectName("statusBar");
        QtInterfaceClass->setStatusBar(statusBar);

        retranslateUi(QtInterfaceClass);
        QObject::connect(btn_sign_up, SIGNAL(clicked()), QtInterfaceClass, SLOT(sign_up()));
        QObject::connect(btn_log_in, SIGNAL(clicked()), QtInterfaceClass, SLOT(log_in()));

        QMetaObject::connectSlotsByName(QtInterfaceClass);
    } // setupUi

    void retranslateUi(QMainWindow *QtInterfaceClass)
    {
        QtInterfaceClass->setWindowTitle(QCoreApplication::translate("QtInterfaceClass", "QtInterface", nullptr));
        label->setText(QCoreApplication::translate("QtInterfaceClass", "Login", nullptr));
        label_2->setText(QCoreApplication::translate("QtInterfaceClass", "Password", nullptr));
#if QT_CONFIG(tooltip)
        le_password->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        le_password->setInputMask(QString());
        le_password->setPlaceholderText(QString());
        btn_log_in->setText(QCoreApplication::translate("QtInterfaceClass", "Log in", nullptr));
        btn_sign_up->setText(QCoreApplication::translate("QtInterfaceClass", "Sign up", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QtInterfaceClass: public Ui_QtInterfaceClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTINTERFACE_H
