/********************************************************************************
** Form generated from reading UI file 'Messenger.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MESSENGER_H
#define UI_MESSENGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MessengerClass
{
public:
    QWidget *centralWidget;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLabel *textLabel;
    QLabel *lbl_my_login;
    QListWidget *list_friends;
    QTextBrowser *textBrowser;
    QLineEdit *le_message;
    QPushButton *btn_send;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MessengerClass)
    {
        if (MessengerClass->objectName().isEmpty())
            MessengerClass->setObjectName("MessengerClass");
        MessengerClass->resize(537, 322);
        centralWidget = new QWidget(MessengerClass);
        centralWidget->setObjectName("centralWidget");
        widget = new QWidget(centralWidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(10, 10, 520, 246));
        gridLayout = new QGridLayout(widget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        textLabel = new QLabel(widget);
        textLabel->setObjectName("textLabel");

        gridLayout->addWidget(textLabel, 0, 0, 1, 1);

        lbl_my_login = new QLabel(widget);
        lbl_my_login->setObjectName("lbl_my_login");

        gridLayout->addWidget(lbl_my_login, 0, 1, 1, 1);

        list_friends = new QListWidget(widget);
        list_friends->setObjectName("list_friends");

        gridLayout->addWidget(list_friends, 1, 0, 1, 2);

        textBrowser = new QTextBrowser(widget);
        textBrowser->setObjectName("textBrowser");

        gridLayout->addWidget(textBrowser, 1, 2, 1, 2);

        le_message = new QLineEdit(widget);
        le_message->setObjectName("le_message");

        gridLayout->addWidget(le_message, 2, 0, 1, 3);

        btn_send = new QPushButton(widget);
        btn_send->setObjectName("btn_send");

        gridLayout->addWidget(btn_send, 2, 3, 1, 1);

        MessengerClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MessengerClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 537, 22));
        MessengerClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MessengerClass);
        mainToolBar->setObjectName("mainToolBar");
        MessengerClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MessengerClass);
        statusBar->setObjectName("statusBar");
        MessengerClass->setStatusBar(statusBar);

        retranslateUi(MessengerClass);
        QObject::connect(list_friends, SIGNAL(itemClicked(QListWidgetItem*)), MessengerClass, SLOT(user_selected(QListWidgetItem*)));
        QObject::connect(btn_send, SIGNAL(clicked()), MessengerClass, SLOT(send_message()));

        QMetaObject::connectSlotsByName(MessengerClass);
    } // setupUi

    void retranslateUi(QMainWindow *MessengerClass)
    {
        MessengerClass->setWindowTitle(QCoreApplication::translate("MessengerClass", "Messenger", nullptr));
        textLabel->setText(QCoreApplication::translate("MessengerClass", "My Login:", nullptr));
        lbl_my_login->setText(QCoreApplication::translate("MessengerClass", "TextLabel", nullptr));
        btn_send->setText(QCoreApplication::translate("MessengerClass", "Send", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MessengerClass: public Ui_MessengerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MESSENGER_H
