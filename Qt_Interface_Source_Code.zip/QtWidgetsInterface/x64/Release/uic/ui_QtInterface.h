/********************************************************************************
** Form generated from reading UI file 'QtInterface.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTINTERFACE_H
#define UI_QTINTERFACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtInterfaceClass
{
public:
    QWidget *centralWidget;
    QWidget *layoutWidget;
    QFormLayout *formLayout;
    QLabel *label_3;
    QLineEdit *le_server_ip;
    QLabel *label;
    QLineEdit *le_login;
    QLabel *label_2;
    QLineEdit *le_password;
    QPushButton *btn_sign_up;
    QPushButton *btn_log_in;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtInterfaceClass)
    {
        if (QtInterfaceClass->objectName().isEmpty())
            QtInterfaceClass->setObjectName("QtInterfaceClass");
        QtInterfaceClass->resize(216, 258);
        centralWidget = new QWidget(QtInterfaceClass);
        centralWidget->setObjectName("centralWidget");
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(30, 10, 158, 176));
        formLayout = new QFormLayout(layoutWidget);
        formLayout->setSpacing(6);
        formLayout->setContentsMargins(11, 11, 11, 11);
        formLayout->setObjectName("formLayout");
        formLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName("label_3");

        formLayout->setWidget(0, QFormLayout::LabelRole, label_3);

        le_server_ip = new QLineEdit(layoutWidget);
        le_server_ip->setObjectName("le_server_ip");

        formLayout->setWidget(1, QFormLayout::SpanningRole, le_server_ip);

        label = new QLabel(layoutWidget);
        label->setObjectName("label");

        formLayout->setWidget(2, QFormLayout::LabelRole, label);

        le_login = new QLineEdit(layoutWidget);
        le_login->setObjectName("le_login");

        formLayout->setWidget(3, QFormLayout::SpanningRole, le_login);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName("label_2");

        formLayout->setWidget(4, QFormLayout::LabelRole, label_2);

        le_password = new QLineEdit(layoutWidget);
        le_password->setObjectName("le_password");
        le_password->setMaxLength(32767);

        formLayout->setWidget(5, QFormLayout::SpanningRole, le_password);

        btn_sign_up = new QPushButton(layoutWidget);
        btn_sign_up->setObjectName("btn_sign_up");

        formLayout->setWidget(6, QFormLayout::LabelRole, btn_sign_up);

        btn_log_in = new QPushButton(layoutWidget);
        btn_log_in->setObjectName("btn_log_in");

        formLayout->setWidget(6, QFormLayout::FieldRole, btn_log_in);

        QtInterfaceClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QtInterfaceClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 216, 22));
        QtInterfaceClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QtInterfaceClass);
        mainToolBar->setObjectName("mainToolBar");
        QtInterfaceClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QtInterfaceClass);
        statusBar->setObjectName("statusBar");
        QtInterfaceClass->setStatusBar(statusBar);

        retranslateUi(QtInterfaceClass);
        QObject::connect(btn_sign_up, SIGNAL(clicked()), QtInterfaceClass, SLOT(sign_up()));
        QObject::connect(btn_log_in, SIGNAL(clicked()), QtInterfaceClass, SLOT(log_in()));

        QMetaObject::connectSlotsByName(QtInterfaceClass);
    } // setupUi

    void retranslateUi(QMainWindow *QtInterfaceClass)
    {
        QtInterfaceClass->setWindowTitle(QCoreApplication::translate("QtInterfaceClass", "QtInterface", nullptr));
        label_3->setText(QCoreApplication::translate("QtInterfaceClass", "Server IP", nullptr));
        label->setText(QCoreApplication::translate("QtInterfaceClass", "Login", nullptr));
        label_2->setText(QCoreApplication::translate("QtInterfaceClass", "Password", nullptr));
#if QT_CONFIG(tooltip)
        le_password->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        le_password->setInputMask(QString());
        le_password->setPlaceholderText(QString());
        btn_sign_up->setText(QCoreApplication::translate("QtInterfaceClass", "Sign up", nullptr));
        btn_log_in->setText(QCoreApplication::translate("QtInterfaceClass", "Log in", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QtInterfaceClass: public Ui_QtInterfaceClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTINTERFACE_H
