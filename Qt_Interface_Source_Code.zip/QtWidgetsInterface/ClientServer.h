#pragma once
#ifndef CLIENTSERVER
#define CLIENTSERVER

#include<QMainWindow>
#include<QTcpSocket>
#include<QString>

class ClientServer
{

};

#endif // !CLIENTSERVER