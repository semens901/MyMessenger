#include "ServerNetwork.h"

ServerNetwork::ServerNetwork()
{
	if (this->listen(QHostAddress::Any, 2000))
	{
		qDebug() << "Start server";
	}
	else
	{
		qDebug() << "Error, server don't start";
	}
	next_block_size = 0;
	db = QSqlDatabase::addDatabase("QSQLITE");
	db.setDatabaseName(DB_NAME);
	if (db.open())
	{
		qDebug() << "opened\t" << DB_NAME;
	}
	else
	{
		qDebug() << "not opened\t" << DB_NAME;
	}
	QSqlQuery query = QSqlQuery(db);

	db_initialize(query);

	db.close();
}

void ServerNetwork::incomingConnection(qintptr socket_descriptor)
{
	socket = new QTcpSocket;
	socket->setSocketDescriptor(socket_descriptor);
	connect(socket, &QTcpSocket::readyRead, this, &ServerNetwork::readyRead);
	connect(socket, &QTcpSocket::disconnected, this, &ServerNetwork::deleteLater);
	sockets.append(socket);

	qDebug() << "Client connected " << socketDescriptor();
}

void ServerNetwork::readyRead()
{
	socket = (QTcpSocket*)sender();
	QDataStream in(socket);
	in.setVersion(QDataStream::Qt_6_5);
	if (in.status() == QDataStream::Ok)
	{
		qDebug() << "read...";
		while (true)
		{
			if (next_block_size == 0)
			{
				qDebug() << "nextBlockSize = 0";

				if (socket->bytesAvailable() < 2)
				{
					qDebug() << "Data < 2, break";
					break;
				}
				in >> next_block_size;
				qDebug() << "nextBlockSize = " << next_block_size;
			}
			if (socket->bytesAvailable() < next_block_size)
			{
				qDebug() << "Data not full, break";
				break;
			}
			in >> js_inpkg;

			next_block_size = 0;
			if (js_inpkg.value("TYPE").toString() == "SIGNUP")
			{
				sign_up(js_inpkg);
			}
			if (js_inpkg.value("TYPE").toString() == "LOGIN")
			{
				log_in(js_inpkg);
			}
			if (js_inpkg.value("TYPE").toString() == "GETUSERSLIST")
			{
				send_users_list(js_inpkg);
			}
			if (js_inpkg.value("TYPE").toString() == "UPDATEMYDATA")
			{
				update_user_data(js_inpkg);
			}
			if (js_inpkg.value("TYPE").toString() == "MESSAGE")
			{
				save_message(js_inpkg);
				update_user_data(js_inpkg);
			}
			break;
		}
	}
	else
	{
		qDebug() << "DataStream error";
	}
}

void ServerNetwork::sign_up(QJsonObject& js_pkg)
{
	QJsonObject js_outpkg;
	qDebug() << js_pkg.value("TYPE").toString() << " " + js_pkg.value("DATA")["LOGIN"].toString() << " " + js_pkg.value("DATA")["PASSWORD"].toString();
	qDebug() << "Atempted registration";

	if (db.open())
	{
		qDebug() << "opened\t" << DB_NAME;
	}
	else
	{
		qDebug() << "not opened\t" << DB_NAME;
	}

	QSqlQuery query = QSqlQuery(db);
	query.prepare("SELECT COUNT(*) FROM users WHERE login = (:login);");
	query.bindValue(":login", js_pkg.value("DATA")["LOGIN"].toString());

	if (!query.exec())
	{
		qDebug() << "Failed to execute query";
	}
	int result = 0;
	while (query.next())
	{
		result += query.value(0).toInt();
	}

	if (!result)
	{
		int id = generate_user_id(query) + 1;

		query.clear();
		query = QSqlQuery(db);
		query.prepare("INSERT INTO users (user_id, login, password) VALUES (:user_id, :login, :password);");
		query.bindValue(":user_id", id);
		query.bindValue(":login", js_pkg.value("DATA")["LOGIN"].toString());
		query.bindValue(":password", js_pkg.value("DATA")["PASSWORD"].toString());

		if (!query.exec())
		{
			qDebug() << "Failed to execute query";
			return;
		}
		js_outpkg = {
				{"TYPE" , "REGISTRATIONSTATUS" },
				{"DATA", NULL},
				{"STATUS", "TRUE"},
				{"USERID", id}
				
		};
		qDebug() << "Registration was successful!";
		sendToClient(js_outpkg, socket);
	}
	else
	{
		qDebug() << "The user could not register!";
		js_outpkg = {
				{"TYPE" , "REGISTRATIONSTATUS" },
				{"DATA", NULL},
				{"STATUS", "FALSE"},
				{"USERID", NULL}

		};
		sendToClient(js_outpkg, socket);
	}
}

void ServerNetwork::log_in(QJsonObject& js_pkg)
{
	QJsonObject js_outpkg;
	qDebug() << js_pkg.value("TYPE").toString() << " " + js_pkg.value("DATA")["LOGIN"].toString() << " " + js_pkg.value("DATA")["PASSWORD"].toString();
	qDebug() << "Entry attempt";
	//QString query = "SELECT COUNT(*) FROM user WHERE login = '" + js_pkg.value("DATA")["LOGIN"].toString() + "' AND password = '" + js_pkg.value("DATA")["PASSWORD"].toString() + "';";

	if (db.open())
	{
		qDebug() << "opened\t" << DB_NAME;
	}
	else
	{
		qDebug() << "not opened\t" << DB_NAME;
	}

	QSqlQuery query = QSqlQuery(db);
	query.prepare("SELECT COUNT(*) FROM users WHERE login = (:login) AND password = (:password);");
	query.bindValue(":login", js_pkg.value("DATA")["LOGIN"].toString());
	query.bindValue(":password", js_pkg.value("DATA")["PASSWORD"].toString());

	if (!query.exec())
	{
		qDebug() << "Failed to execute query";
	}
	int result = 0;
	while (query.next())
	{
		result += query.value(0).toInt();
	}

	if (result)
	{
		int id = NULL;
		query.prepare("SELECT user_id FROM users WHERE login = (:login) AND password = (:password);");
		query.bindValue(":login", js_pkg.value("DATA")["LOGIN"].toString());
		query.bindValue(":password", js_pkg.value("DATA")["PASSWORD"].toString());
		if (!query.exec())
		{
			qDebug() << "Failed to execute query";
			return;
		}
		if (query.next())
		{
			id = query.value(0).toInt();
		}
		else
		{
			return;
		}
		js_outpkg = {
				{"TYPE" , "LOGINSTATUS" },
				{"DATA", NULL},
				{"STATUS", "TRUE"},
				{"USERID", id}

		};
		sendToClient(js_outpkg, socket);
		qDebug() << "Login was successful!";
	}
	else
	{
		js_outpkg = {
				{"TYPE" , "LOGINSTATUS" },
				{"DATA", NULL},
				{"STATUS", "FALSE"},
				{"USERID", NULL}

		};
		sendToClient(js_outpkg, socket);
		qDebug() << "Login or password is not correct!";
	}
}

void ServerNetwork::send_users_list(QJsonObject& js_pkg)
{
	QJsonObject js_outpkg;
	QStringList users = get_users_list(); 
	js_outpkg = {
				{"TYPE" , "GETUSERSLIST" },
				{"DATA", NULL},
				{"STATUS", "TRUE"}

	};

	QSqlQuery query = QSqlQuery(db);
	QMap<QString, int> m_users;
	int id = 0;
	for (auto var : users)
	{
		query.prepare("SELECT user_id FROM users WHERE login = (:login)");
		query.bindValue(":login", var);
		if (!query.exec())
		{
			qDebug() << "Failed to execute query";
			return;
		}
		if (query.next())
		{
			id = query.value(0).toInt();
		}
		else
		{
			id = NULL;
		}
		m_users[var] = id;
	}
	QJsonArray data_list;
	for (auto var : users)
		data_list.append(var);
	js_outpkg["DATA"] = data_list;
	QJsonArray id_users;
	for (auto var : users)
	{
		id_users.append(m_users[var]);
	}
		
	js_outpkg["USERSID"] = id_users;
	this->users[js_pkg.value("USERID").toInt()].push_back(socket);
	for (QMap<int, QVector<QTcpSocket*>>::iterator it = this->users.begin(); it != this->users.end(); ++it)
	{
		for (QVector<QTcpSocket*>::iterator it_value = it.value().begin(); it_value != it.value().end(); ++it_value)
		{
			sendToClient(js_outpkg, *it_value);
		}

	}
}

QStringList ServerNetwork::get_users_list()
{
	QStringList users;
	db = QSqlDatabase::addDatabase("QSQLITE");
	db.setDatabaseName(DB_NAME);
	if (db.open())
	{
		qDebug() << "opened\t" << DB_NAME;
	}
	else
	{
		qDebug() << "not opened\t" << DB_NAME;
	}
	QSqlQuery query = QSqlQuery(db);
	query.prepare("SELECT * FROM users");
	if (!query.exec())
	{
		qDebug() << "Failed to execute query";
	}
	while (query.next())
	{
		qDebug() << query.value(1).toString();
		users.append(query.value(1).toString());
	}
	//db.close();
	return users;
}

int ServerNetwork::generate_user_id(QSqlQuery& query)
{
	query.exec("SELECT * FROM users ORDER BY user_id DESC LIMIT 1;");
	if (query.next())
		return query.value(0).toInt();
}

int ServerNetwork::generate_message_id(QSqlQuery& query)
{
	query.exec("SELECT * FROM messages ORDER BY message_id DESC LIMIT 1;");
	if (query.next())
		return query.value(0).toInt();
}

void ServerNetwork::db_initialize(QSqlQuery& query)
{
	query.exec("CREATE TABLE users ("
		"user_id INT AUTO_INCREMENT PRIMARY KEY,"
		"login VARCHAR(50) NOT NULL UNIQUE,"
		"password VARCHAR(255) NOT NULL"
		");");

	query.exec("CREATE TABLE chats ("
		"chat_id INTEGER PRIMARY KEY,"
		"name VARCHAR(50) NOT NULL UNIQUE,"
		"created_at DATETIME DEFAULT CURRENT_TIMESTAMP"
		");");
	query.exec("CREATE TABLE members ("
		"member_id INTEGER PRIMARY KEY,"
		"chat_id INTEGER NOT NULL,"
		"user_id INTEGER NOT NULL,"
		"created_at DATETIME DEFAULT CURRENT_TIMESTAMP,"
		"FOREIGN KEY (chat_id) REFERENCES chats(chat_id),"
		"FOREIGN KEY (user_id) REFERENCES users(user_id)"
		");");

	query.exec("CREATE TABLE messages ("
		"message_id INT AUTO_INCREMENT PRIMARY KEY,"
		"chat_id INTEGER NOT NULL,"
		"user_id INTEGER NOT NULL,"
		"message VARCHAR(255) NOT NULL,"
		"send_to INTEGER NOT NULL,"
		"FOREIGN KEY (chat_id) REFERENCES chats(chat_id),"
		"FOREIGN KEY (user_id) REFERENCES users(user_id)"
		");");
}

void ServerNetwork::save_message(QJsonObject& js_pkg)
{
	int message_id = 0;
	if (db.open())
	{
		qDebug() << "opened\t" << DB_NAME;
	}
	else
	{
		qDebug() << "not opened\t" << DB_NAME;
	}

	QSqlQuery query = QSqlQuery(db);
	message_id = generate_message_id(query) + 1;
	qDebug() << "Message ID: " + QString::number(message_id) + " Chat ID: " + QString::number(message_id);
	qDebug() << "Message: " + js_pkg["DATA"].toString();
	qDebug() << "Send to: " + js_pkg["SENDTO"].toInt();
	query.prepare("INSERT INTO messages (message_id, chat_id, user_id, message, send_to) VALUES (:message_id, :chat_id, :user_id, :message, :send_to);");
	query.bindValue(":message_id", message_id);
	query.bindValue(":chat_id", message_id);
	query.bindValue(":user_id", js_pkg["USERID"].toInt());
	query.bindValue(":message", js_pkg["DATA"].toString());
	query.bindValue(":send_to", js_pkg["SENDTO"].toInt());
	if (!query.exec())
	{
		qDebug() << "Failed to execute query";
	}

}

void ServerNetwork::update_user_data(QJsonObject& js_pkg)
{
	QJsonObject js_outpkg = {
		{"TYPE" , "UPDATEMYDATA" },
		{"STATUS", NULL},
		{"USERID", js_pkg.value("USERID").toInt()},
		{"SENDTO", js_pkg.value("SENDTO").toInt()},
		{"DATA", NULL}
	};
	QJsonObject js_outpkg2 = {
		{"TYPE" , "UPDATEMYDATA" },
		{"STATUS", NULL},
		{"USERID", js_pkg.value("SENDTO").toInt()},
		{"SENDTO", js_pkg.value("USERID").toInt()},
		{"DATA", NULL}
	};
	QSqlQuery query = QSqlQuery(db);

	query.prepare("SELECT * FROM messages WHERE (user_id = (:user_id) AND send_to = (:send_to)) OR (user_id = (:send_to) AND send_to = (:user_id));");
	query.bindValue(":user_id", js_pkg.value("USERID").toInt());
	query.bindValue(":send_to", js_pkg.value("SENDTO").toInt());
	if (!query.exec())
	{
		qDebug() << "Failed to execute query";
	}
	QJsonArray users_id;
	QJsonArray messages;
	QJsonArray sends_to;
	while (query.next())
	{

		/*qDebug() << "message_id: " + query.value(0).toString();
		qDebug() << "chat_id: " + query.value(1).toString();
		qDebug() << "user_id: " + query.value(2).toString();
		qDebug() << "message: " + query.value(3).toString();
		qDebug() << "send_to: " + query.value(4).toString();*/
		users_id.append(query.value(2).toInt());
		messages.append(query.value(3).toString());
		sends_to.append(query.value(4).toInt());
	}
	js_outpkg["USERSID"] = users_id;
	js_outpkg["MESSAGES"] = messages;
	js_outpkg["SENDSTO"] = sends_to;

	js_outpkg2["USERSID"] = users_id;
	js_outpkg2["MESSAGES"] = messages;
	js_outpkg2["SENDSTO"] = sends_to;

	/*for(auto sock : sockets)
		sendToClient(js_outpkg, sock);*/

	for (QMap<int, QVector<QTcpSocket*>>::iterator it = users.begin(); it != users.end(); ++it)
	{
		if (it.key() == js_pkg["USERID"].toInt())
		{
			for (auto var : it.value())
			{
				sendToClient(js_outpkg, var);
			}
		}
		if (it.key() == js_outpkg2["USERID"].toInt())
		{
			for (auto var : it.value())
			{
				sendToClient(js_outpkg2, var);
			}
		}
	}
}

void ServerNetwork::sendToClient(QJsonObject& js_pkg, QTcpSocket* socket)
{
	qDebug() << js_pkg.value("TYPE").toString() << " Client " + socket->peerAddress().toString();
	data.clear();
	QDataStream out(&data, QIODevice::WriteOnly);
	out.setVersion(QDataStream::Qt_6_5);
	out << quint64(0) << js_pkg;
	out.device()->seek(0);
	out << quint64(data.size() - sizeof(quint64));
	//out << str;
	//socket->write(data);
	if(socket != NULL)
		socket->write(data);
}

void ServerNetwork::deleteLater()
{
	for (QMap<int, QVector<QTcpSocket*>>::iterator it = users.begin(); it != users.end(); ++it)
	{
		for (QVector<QTcpSocket*>::iterator it_value = it.value().begin(); it_value != it.value().end(); ++it_value)
		{
			if (*it_value == (QTcpSocket*)sender())
			{
				users[it.key()].erase(it_value);
				return;
			}
		}

	}
}
